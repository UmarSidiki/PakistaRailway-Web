import { useEffect, useMemo } from 'react';
import { create } from 'zustand';
import type { StoreApi } from 'zustand';
import { shallow } from 'zustand/shallow';
import type {
  ConnectionStatus,
  LiveTrainDelta,
  TrainFilters,
  TrainWithRoute,
  StationDetails
} from '@/types';
import {
  loadTrainDataset,
  loadTrainDatasetSync,
  persistTrainSnapshot,
  stripStaleLiveData,
  STALE_LIVE_RUN_TTL_MS
} from '@/services/dataLoader';
import { connectLiveSocket } from '@/services/socket';
import { applyRunSelectionToTrain, findMatchingTrainId, updateTrainWithDelta } from '@/services/liveData';
import { isPassengerTrain } from '@/lib/train';

const { trains: initialTrains, stationById: initialStationLookup } = loadTrainDatasetSync();

export interface TrainStoreState {
  trains: TrainWithRoute[];
  stationLookup: Map<number, StationDetails>;
  isDatasetHydrated: boolean;
  filters: TrainFilters;
  selectedTrainId?: number;
  liveDeltas: Map<string, LiveTrainDelta>;
  trainKeyToId: Map<string, number>;
  selectedRunIds: Map<number, string>;
  unresolvedDeltas: Map<string, LiveTrainDelta>;
  connectionStatus: ConnectionStatus;
  lastSocketEvent?: number;
  lastError?: string;
  setFilters: (partial: Partial<TrainFilters>) => void;
  selectTrain: (trainId: number) => void;
  applyDeltas: (deltas: LiveTrainDelta[]) => void;
  setConnectionStatus: (status: ConnectionStatus) => void;
  setLastError: (message?: string) => void;
  selectTrainRun: (trainId: number, runId: string) => void;
  setDataset: (dataset: { trains: TrainWithRoute[]; stationById: Map<number, StationDetails> }) => void;
  pruneStaleRuns: () => void;
}

const defaultFilters: TrainFilters = {
  search: '',
  onlyLive: false,
  onlyPassenger: true,
  direction: 'all'
};

const useTrainStore = create<TrainStoreState>()(
  (set: StoreApi<TrainStoreState>['setState']) => ({
    trains: initialTrains,
    stationLookup: initialStationLookup,
    isDatasetHydrated: false,
    filters: defaultFilters,
    selectedTrainId: undefined,
    liveDeltas: new Map(),
    trainKeyToId: new Map(),
    selectedRunIds: new Map(),
    unresolvedDeltas: new Map(),
    connectionStatus: 'connecting',
    lastSocketEvent: undefined,
    lastError: undefined,
    setDataset: (dataset) =>
      set({
        trains: dataset.trains,
        stationLookup: dataset.stationById,
        isDatasetHydrated: true
      }),
    setFilters: (partial: Partial<TrainFilters>) =>
      set((state: TrainStoreState) => ({
        filters: {
          ...state.filters,
          ...partial
        }
      })),
    selectTrain: (trainId: number) => set({ selectedTrainId: trainId }),
    applyDeltas: (deltas: LiveTrainDelta[]) => {
      if (deltas.length === 0) {
        return;
      }

      let nextTrains: TrainWithRoute[] | undefined;
      set((state: TrainStoreState) => {
        const liveDeltas = new Map(state.liveDeltas);
        const trainKeyToId = new Map(state.trainKeyToId);
        const selectedRunIds = new Map(state.selectedRunIds);
        const unresolvedDeltas = new Map(state.unresolvedDeltas);
        let trains = state.trains;

        deltas.forEach((delta) => {
          liveDeltas.set(delta.trainKey, delta);

          const mappedTrainId =
            trainKeyToId.get(delta.id) ??
            trainKeyToId.get(delta.trainKey) ??
            trainKeyToId.get(delta.variantKey) ??
            (delta.trainNumber != null ? trainKeyToId.get(String(delta.trainNumber)) : undefined);
          let targetTrainId = mappedTrainId;

          if (!targetTrainId) {
            targetTrainId = findMatchingTrainId(trains, delta);
            if (targetTrainId) {
              trainKeyToId.set(delta.id, targetTrainId);
              trainKeyToId.set(delta.trainKey, targetTrainId);
              trainKeyToId.set(delta.variantKey, targetTrainId);
              if (delta.trainNumber != null) {
                trainKeyToId.set(String(delta.trainNumber), targetTrainId);
              }
            }
          }

          if (targetTrainId) {
            trains = trains.map((train) =>
              train.TrainId === targetTrainId
                ? updateTrainWithDelta(train, delta, selectedRunIds.get(train.TrainId))
                : train
            );

            const updatedTrain = trains.find((train) => train.TrainId === targetTrainId);
            if (updatedTrain?.selectedRunId) {
              selectedRunIds.set(targetTrainId, updatedTrain.selectedRunId);
            }
            unresolvedDeltas.delete(delta.id);
          } else {
            unresolvedDeltas.set(delta.id, delta);
          }
        });

        const now = Date.now();
        liveDeltas.forEach((delta, key) => {
          if (now - delta.lastUpdated > STALE_LIVE_RUN_TTL_MS) {
            liveDeltas.delete(key);
          }
        });

        const sanitizedTrains = stripStaleLiveData(trains, now);
        if (sanitizedTrains !== trains) {
          sanitizedTrains.forEach((train) => {
            if (!train.selectedRunId) {
              selectedRunIds.delete(train.TrainId);
            }
          });
        }

        trains = sanitizedTrains;
        const shouldPromoteConnection = state.connectionStatus !== 'connected';

        nextTrains = trains;

        return {
          trains,
          liveDeltas,
          trainKeyToId,
          selectedRunIds,
          unresolvedDeltas,
          lastSocketEvent: now,
          ...(shouldPromoteConnection
            ? {
                connectionStatus: 'connected' as ConnectionStatus,
                lastError: undefined
              }
            : {})
        };
      });

      if (nextTrains) {
        persistTrainSnapshot(nextTrains).catch((err) => {
          console.error('Failed to persist live snapshot', err);
        });
      }
    },
    pruneStaleRuns: () => {
      let persisted: TrainWithRoute[] | undefined;
      set((state: TrainStoreState) => {
        const now = Date.now();
        const trains = stripStaleLiveData(state.trains, now);
        if (trains === state.trains) {
          return {};
        }

        const selectedRunIds = new Map(state.selectedRunIds);
        trains.forEach((train) => {
          if (!train.selectedRunId) {
            selectedRunIds.delete(train.TrainId);
          }
        });

        const liveDeltas = new Map(state.liveDeltas);
        liveDeltas.forEach((delta, key) => {
          if (now - delta.lastUpdated > STALE_LIVE_RUN_TTL_MS) {
            liveDeltas.delete(key);
          }
        });

        persisted = trains;

        return {
          trains,
          selectedRunIds,
          liveDeltas
        };
      });

      if (persisted) {
        persistTrainSnapshot(persisted).catch((err) => {
          console.error('Failed to persist pruned snapshot', err);
        });
      }
    },
    setConnectionStatus: (status: ConnectionStatus) =>
      set((state) => ({
        connectionStatus: status,
        ...(status === 'connected' ? { lastError: undefined } : {})
      })),
    setLastError: (message?: string) => set({ lastError: message }),
    selectTrainRun: (trainId: number, runId: string) =>
      set((state: TrainStoreState) => {
        const trains = state.trains.map((train) =>
          train.TrainId === trainId ? applyRunSelectionToTrain(train, runId) : train
        );

        const selectedRunIds = new Map(state.selectedRunIds);
        const targetTrain = trains.find((train) => train.TrainId === trainId);
        if (targetTrain?.selectedRunId) {
          selectedRunIds.set(trainId, targetTrain.selectedRunId);
        }

        return {
          trains,
          selectedRunIds
        };
      })
  })
);

export const useTrainFilters = () =>
  useTrainStore((state: TrainStoreState) => ({
    filters: state.filters,
    setFilters: state.setFilters
  }));

export const useSelectedTrain = () =>
  useTrainStore(
    (state: TrainStoreState) => ({
      selectedTrain: state.trains.find((train: TrainWithRoute) => train.TrainId === state.selectedTrainId),
      selectTrain: state.selectTrain,
      selectTrainRun: state.selectTrainRun
    }),
    shallow
  );

export const useFilteredTrains = () =>
  useTrainStore((state: TrainStoreState) => {
    const { filters, trains } = state;
    const search = filters.search.trim().toLowerCase();

    return trains.filter((train: TrainWithRoute) => {
      const matchesSearch =
        search.length === 0 ||
        train.TrainName.toLowerCase().includes(search) ||
        train.TrainDescription?.toLowerCase().includes(search) ||
        String(train.TrainNumber).includes(search);

      const matchesLive = !filters.onlyLive || train.livePosition || train.IsLive;

      const matchesDirection =
        filters.direction === 'all' ||
        (filters.direction === 'up' && train.IsUp) ||
        (filters.direction === 'down' && !train.IsUp);

      const matchesPassenger = !filters.onlyPassenger || isPassengerTrain(train);

      return matchesSearch && matchesLive && matchesDirection && matchesPassenger;
    });
  }, shallow);

export const useStationLookup = () =>
  useTrainStore((state: TrainStoreState) => state.stationLookup);

export const useDatasetBootstrap = () => {
  const setDataset = useTrainStore((state: TrainStoreState) => state.setDataset);
  const isHydrated = useTrainStore((state: TrainStoreState) => state.isDatasetHydrated);

  useEffect(() => {
    if (isHydrated) return;

    let cancelled = false;
    loadTrainDataset()
      .then((dataset) => {
        if (!cancelled) {
          setDataset(dataset);
        }
      })
      .catch((err) => {
        console.error('Failed to load dataset from IndexedDB', err);
        setDataset(loadTrainDatasetSync());
      });

    return () => {
      cancelled = true;
    };
  }, [isHydrated, setDataset]);
};

export const useLiveSocket = () => {
  const applyDeltas = useTrainStore((state: TrainStoreState) => state.applyDeltas);
  const setConnectionStatus = useTrainStore((state: TrainStoreState) => state.setConnectionStatus);
  const setLastError = useTrainStore((state: TrainStoreState) => state.setLastError);
  const pruneStaleRuns = useTrainStore((state: TrainStoreState) => state.pruneStaleRuns);

  useEffect(() => {
    setConnectionStatus('connecting');
    const disconnect = connectLiveSocket(
      (deltas) => {
        applyDeltas(deltas);
      },
      {
        onConnect: () => {
          setConnectionStatus('connected');
          setLastError(undefined);
        },
        onDisconnect: () => {
          setConnectionStatus('disconnected');
        },
        onReconnectAttempt: () => {
          setConnectionStatus('reconnecting');
        },
        onReconnect: () => {
          setConnectionStatus('connected');
          setLastError(undefined);
        },
        onError: (err) => {
          setLastError(err.message);
          setConnectionStatus('error');
        }
      }
    );

    return () => {
      setConnectionStatus('disconnected');
      disconnect();
    };
  }, [applyDeltas, setConnectionStatus, setLastError]);

  useEffect(() => {
    pruneStaleRuns();
    const interval = window.setInterval(() => {
      pruneStaleRuns();
    }, STALE_LIVE_RUN_TTL_MS);

    return () => {
      window.clearInterval(interval);
    };
  }, [pruneStaleRuns]);
};

export const useDashboardData = () => {
  const trains = useFilteredTrains();
  const { filters, setFilters } = useTrainFilters();
  const { selectedTrain, selectTrain, selectTrainRun } = useSelectedTrain();
  const allTrains = useTrainStore((state: TrainStoreState) => state.trains);
  const liveCount = useTrainStore((state: TrainStoreState) => state.liveDeltas.size);
  const unresolvedCount = useTrainStore((state: TrainStoreState) => state.unresolvedDeltas.size);
  const connectionStatus = useTrainStore((state: TrainStoreState) => state.connectionStatus);
  const lastSocketEvent = useTrainStore((state: TrainStoreState) => state.lastSocketEvent);
  const lastError = useTrainStore((state: TrainStoreState) => state.lastError);

  return useMemo(
    () => ({
      allTrains,
      trains,
      filters,
      setFilters,
      selectedTrain,
      selectTrain,
      selectTrainRun,
      liveCount,
      unresolvedCount,
      connectionStatus,
      lastSocketEvent,
      lastError
    }),
    [
      allTrains,
      connectionStatus,
      filters,
      lastError,
      lastSocketEvent,
      unresolvedCount,
      liveCount,
      selectTrain,
      selectTrainRun,
      selectedTrain,
      setFilters,
      trains
    ]
  );
};

export const useSocketMeta = () =>
  useTrainStore(
    (state: TrainStoreState) => ({
      connectionStatus: state.connectionStatus,
      lastSocketEvent: state.lastSocketEvent,
      lastError: state.lastError
    }),
    shallow
  );
