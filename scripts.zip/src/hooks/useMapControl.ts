import { useState, useEffect, useCallback, useRef } from 'react';
import type { Map as LeafletMap } from 'leaflet';
import L from 'leaflet';
import {
  DEFAULT_MAP_CENTER,
  DEFAULT_ZOOM,
  TRAIN_FOCUS_ZOOM,
  ROUTE_OVERVIEW_ZOOM,
  MAX_ROUTE_ZOOM,
  BOUNDS_PADDING,
  ANIMATION_DURATION,
  USER_OVERRIDE_TIMEOUT
} from '@/lib/map/constants';

interface MapControlOptions {
  selectedPosition?: [number, number];
  displayedPoints: [number, number][];
  routePoints: [number, number][];
  hasLivePosition: boolean;
}

/**
 * Custom hook for managing map interactions and auto-follow behavior
 */
export const useMapControl = (options: MapControlOptions) => {
  const { selectedPosition, displayedPoints, routePoints, hasLivePosition } = options;
  
  const [mapInstance, setMapInstance] = useState<LeafletMap | null>(null);
  const [userOverrideActive, setUserOverrideActive] = useState(false);
  const overrideTimerRef = useRef<number | null>(null);

  /**
   * Clears the user override timer
   */
  const clearOverrideTimer = useCallback(() => {
    if (overrideTimerRef.current != null) {
      window.clearTimeout(overrideTimerRef.current);
      overrideTimerRef.current = null;
    }
  }, []);

  /**
   * Schedules reset of user override after timeout
   */
  const scheduleOverrideReset = useCallback(() => {
    clearOverrideTimer();
    overrideTimerRef.current = window.setTimeout(() => {
      setUserOverrideActive(false);
      overrideTimerRef.current = null;
    }, USER_OVERRIDE_TIMEOUT);
  }, [clearOverrideTimer]);

  /**
   * Handles user interaction with the map (drag, zoom, click)
   */
  const handleUserInteraction = useCallback(() => {
    setUserOverrideActive(true);
    scheduleOverrideReset();
  }, [scheduleOverrideReset]);

  /**
   * Centers map on selected train position
   */
  const centerOnTrain = useCallback(() => {
    if (!mapInstance || !selectedPosition) return;
    
    clearOverrideTimer();
    setUserOverrideActive(false);
    mapInstance.flyTo(selectedPosition, TRAIN_FOCUS_ZOOM, {
      animate: true,
      duration: ANIMATION_DURATION
    });
  }, [mapInstance, selectedPosition, clearOverrideTimer]);

  /**
   * Fits map to show entire route
   */
  const fitRoute = useCallback(() => {
    if (!mapInstance || routePoints.length === 0) return;
    
    clearOverrideTimer();
    setUserOverrideActive(false);

    if (routePoints.length === 1) {
      mapInstance.flyTo(routePoints[0], ROUTE_OVERVIEW_ZOOM, {
        animate: true,
        duration: ANIMATION_DURATION
      });
      return;
    }

    const bounds = L.latLngBounds(routePoints.map(([lat, lon]) => L.latLng(lat, lon)));
    mapInstance.fitBounds(bounds, {
      padding: BOUNDS_PADDING,
      maxZoom: MAX_ROUTE_ZOOM
    });
  }, [mapInstance, routePoints, clearOverrideTimer]);

  /**
   * Resets map to default view
   */
  const resetView = useCallback(() => {
    if (!mapInstance) return;
    
    clearOverrideTimer();
    setUserOverrideActive(false);
    mapInstance.setView(DEFAULT_MAP_CENTER, DEFAULT_ZOOM, { animate: true });
  }, [mapInstance, clearOverrideTimer]);

  /**
   * Auto-follow train position when not overridden by user
   */
  useEffect(() => {
    if (!mapInstance || userOverrideActive) return;

    if (hasLivePosition && selectedPosition) {
      mapInstance.flyTo(selectedPosition, TRAIN_FOCUS_ZOOM, {
        animate: true,
        duration: ANIMATION_DURATION
      });
      return;
    }

    if (displayedPoints.length > 1) {
      const bounds = L.latLngBounds(displayedPoints.map(([lat, lon]) => L.latLng(lat, lon)));
      mapInstance.fitBounds(bounds, {
        padding: BOUNDS_PADDING,
        maxZoom: MAX_ROUTE_ZOOM - 0.5
      });
    } else if (displayedPoints.length === 1) {
      mapInstance.flyTo(displayedPoints[0], ROUTE_OVERVIEW_ZOOM, {
        animate: true,
        duration: ANIMATION_DURATION
      });
    } else if (routePoints.length > 1) {
      const bounds = L.latLngBounds(routePoints.map(([lat, lon]) => L.latLng(lat, lon)));
      mapInstance.fitBounds(bounds, {
        padding: BOUNDS_PADDING,
        maxZoom: MAX_ROUTE_ZOOM
      });
    } else if (routePoints.length === 1) {
      mapInstance.flyTo(routePoints[0], ROUTE_OVERVIEW_ZOOM - 0.5, {
        animate: true,
        duration: ANIMATION_DURATION
      });
    } else {
      mapInstance.setView(DEFAULT_MAP_CENTER, DEFAULT_ZOOM, { animate: true });
    }
  }, [mapInstance, selectedPosition, displayedPoints, routePoints, hasLivePosition, userOverrideActive]);

  /**
   * Reset override when selected train changes
   */
  useEffect(() => {
    clearOverrideTimer();
    setUserOverrideActive(false);
  }, [selectedPosition?.[0], selectedPosition?.[1], clearOverrideTimer]);

  /**
   * Cleanup timer on unmount
   */
  useEffect(() => {
    return () => clearOverrideTimer();
  }, [clearOverrideTimer]);

  return {
    mapInstance,
    setMapInstance,
    userOverrideActive,
    handleUserInteraction,
    centerOnTrain,
    fitRoute,
    resetView
  };
};
