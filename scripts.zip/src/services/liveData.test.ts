import { describe, expect, it, vi } from 'vitest';
import { applyRunSelectionToTrain, findMatchingTrainId, parseSocketPayload, updateTrainWithDelta } from './liveData';
import type { SocketTrainPayload, TrainStop, TrainWithRoute } from '@/types';

const buildStop = (stationId: number, order: number, name: string): TrainStop => ({
  TrainNumber: 1,
  TrainName: 'Test Express',
  StationId: stationId,
  ArrivalTime: '10:00:00',
  IsDayChanged: 0,
  DayCount: 0,
  DepartureTime: '10:05:00',
  IsUp: 1,
  OrderNumber: order,
  StationName: name,
  Latitude: 30 + order,
  Longitude: 70 + order
});

const buildTrain = (
  id: number,
  isUp: boolean,
  stopIds: number[],
  extras: Partial<Omit<TrainWithRoute, 'route'>> = {}
): TrainWithRoute => ({
  TrainId: id,
  TrainNumber: extras.TrainNumber ?? id,
  TrainName: extras.TrainName ?? `Test Train ${id}`,
  TrainNameUR: 'ٹیسٹ',
  TrainNameWithNumber: extras.TrainNameWithNumber ?? `Test Train ${id}`,
  TrainDescription: extras.TrainDescription ?? 'Sample description',
  IsActive: extras.IsActive ?? true,
  Imei: extras.Imei ?? null,
  IsLive: extras.IsLive ?? true,
  IsUp: isUp,
  LocomotiveNumber: extras.LocomotiveNumber ?? null,
  TrainRideId: extras.TrainRideId ?? 0,
  AllocatedDate: extras.AllocatedDate ?? null,
  route: stopIds.map((stationId, index) => buildStop(stationId, index + 1, `Station ${stationId}`)),
  upcomingStop: extras.upcomingStop,
  previousStop: extras.previousStop,
  livePosition: extras.livePosition
});

describe('parseSocketPayload', () => {
  it('parses numeric fields and metadata correctly', () => {
    const payload: SocketTrainPayload = {
      locomitiveNo: '9017',
      lat: '31.170310',
      lon: '74.098983',
      last_updated: '1759267971',
      late_by: '-90',
      next_station: '151',
      next_stop: 'Shaheenabad Jn',
      prev_station: '152',
      sp: '16',
      isTrainStation: 'False',
      isTrainStop: 'False',
      isFlagged: 'False',
      icon: 'https://example.com/BlueUp.png',
      st: 'A',
      __last_updated: 1759267970731
    };

    const delta = parseSocketPayload('129900', '1230099900', payload);
    expect(delta).not.toBeNull();

    expect(delta).toMatchObject({
      trainKey: '129900',
      variantKey: '1230099900',
      locomitiveNo: '9017',
      lat: 31.17031,
      lon: 74.098983,
      nextStationId: 151,
      prevStationId: 152,
      speed: 16,
      trainNumber: 12,
      dayNumber: null,
      statusCode: 'A',
      direction: 'up'
    });
    expect(delta?.lateBy).toBe(-90);
    expect(delta?.isTrainStation).toBe(false);
  });

  it('merges multiple runs while honouring preferred selection', () => {
    const baseTrain = buildTrain(30, true, [100, 151, 200]);
    baseTrain.route[1].DayCount = 1;
    baseTrain.route[2].DayCount = 2;

    const firstPayload: SocketTrainPayload = {
      lat: '31.10',
      lon: '70.20',
      next_station: '151',
      prev_station: '100',
      sp: '45',
      icon: 'https://example.com/BlueUp.png',
      __last_updated: 1000
    };

    const secondPayload: SocketTrainPayload = {
      lat: '32.10',
      lon: '71.20',
      next_station: '200',
      prev_station: '151',
      sp: '42',
      icon: 'https://example.com/BlueUp.png',
      __last_updated: 2000
    };

    const firstDelta = parseSocketPayload('3019900', '3010099900', firstPayload);
    const secondDelta = parseSocketPayload('3019900', '3010099901', secondPayload);

    expect(firstDelta).not.toBeNull();
    expect(secondDelta).not.toBeNull();

    let trainState = updateTrainWithDelta(baseTrain, firstDelta!);
    expect(trainState.liveRuns).toHaveLength(1);
    expect(trainState.livePosition?.dayNumber).toBe(1);
    expect(trainState.upcomingStop?.StationId).toBe(151);

    trainState = updateTrainWithDelta(trainState, secondDelta!, trainState.selectedRunId);

    expect(trainState.liveRuns).toHaveLength(2);
    expect(trainState.liveRuns?.map((run) => run.dayNumber)).toEqual(expect.arrayContaining([1, 2]));
    expect(trainState.livePosition?.id).toBe(firstDelta!.id);

    const reselected = applyRunSelectionToTrain(trainState, secondDelta!.id);
    expect(reselected.selectedRunId).toBe(secondDelta!.id);
    expect(reselected.livePosition?.dayNumber).toBe(2);
    expect(reselected.upcomingStop?.StationId).toBe(200);
  });
});

describe('findMatchingTrainId', () => {
  const trains: TrainWithRoute[] = [
    buildTrain(1, true, [100, 151, 200]),
    buildTrain(2, false, [300, 152, 151])
  ];

  it('prefers train number when available', () => {
    const payload: SocketTrainPayload = {
      lat: '30.50',
      lon: '70.50',
      sp: '55'
    };

    const delta = parseSocketPayload('29900', 'variant', payload);
    expect(delta).not.toBeNull();

    const match = findMatchingTrainId(trains, delta!);
    expect(match).toBe(2);
  });

  it('matches train using next and previous station ids', () => {
    const payload: SocketTrainPayload = {
      lat: '31.00',
      lon: '70.00',
      next_station: '200',
      prev_station: '151',
      icon: 'Up',
      sp: '50'
    };

    const delta = parseSocketPayload('key-without-number', 'variant-without-number', payload);
    expect(delta).not.toBeNull();

    const match = findMatchingTrainId(trains, delta!);
    expect(match).toBe(1);
  });

  it('falls back to direction when multiple trains share stations', () => {
    const payload: SocketTrainPayload = {
      lat: '32.00',
      lon: '70.00',
      next_station: '151',
      prev_station: '152',
      icon: 'Down',
      sp: '45'
    };

    const delta = parseSocketPayload('no-number', 'variant', payload);
    expect(delta).not.toBeNull();
    const match = findMatchingTrainId(trains, delta!);
    expect(match).toBe(2);
  });

  it('uses locomotive number to break ties', () => {
    const customTrains: TrainWithRoute[] = [
      buildTrain(10, true, [100, 151, 200]),
      buildTrain(11, true, [100, 151, 200], { LocomotiveNumber: '6402' })
    ];

    const payload: SocketTrainPayload = {
      lat: '31.00',
      lon: '70.00',
      next_station: '200',
      prev_station: '151',
      icon: 'https://example.com/BlueUp.png',
      locomitiveNo: '6402'
    };

    const delta = parseSocketPayload('unknown-key', 'variant', payload);
    expect(delta).not.toBeNull();
    const match = findMatchingTrainId(customTrains, delta!);
    expect(match).toBe(11);
  });

  it('returns undefined when candidates remain tied', () => {
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});

    const customTrains: TrainWithRoute[] = [
      buildTrain(20, true, [100, 151, 200]),
      buildTrain(21, true, [100, 151, 200])
    ];

    const payload: SocketTrainPayload = {
      lat: '30.00',
      lon: '70.00',
      next_station: '200',
      prev_station: '151',
      icon: 'https://example.com/BlueUp.png'
    };

    const delta = parseSocketPayload('ambiguous', 'variant', payload);
    expect(delta).not.toBeNull();
    const match = findMatchingTrainId(customTrains, delta!);
    expect(match).toBeUndefined();
    expect(warnSpy).toHaveBeenCalled();
    warnSpy.mockRestore();
  });
});
