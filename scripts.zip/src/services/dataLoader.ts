import trainsRaw from '../../datapoints/trains.json';
import trainStationsRaw from '../../datapoints/trainStations.json';
import stationsRaw from '../../datapoints/stationsData.json';
import type {
  ApiEnvelope,
  TrainSummary,
  TrainStationsMapEntry,
  StationDetails,
  TrainWithRoute,
  TrainStop,
  LiveTrainDelta
} from '@/types';
import { db } from './db';

const trainsEnvelope = trainsRaw as ApiEnvelope<TrainSummary[]>;
const stationsEnvelope = stationsRaw as ApiEnvelope<StationDetails[]>;
const trainStationsList = trainStationsRaw as TrainStationsMapEntry[];

export interface TrainDataset {
  trains: TrainWithRoute[];
  stationById: Map<number, StationDetails>;
}

const buildStationMap = (collection: StationDetails[]): Map<number, StationDetails> =>
  new Map(collection.map((station) => [station.StationDetailsId, station]));

const buildRouteMap = (entries: TrainStationsMapEntry[]): Map<number, TrainStop[]> =>
  new Map(
    entries.map((entry) => [
      entry.TrainId,
      [...entry.stations].sort((a, b) => a.OrderNumber - b.OrderNumber)
    ])
  );

const buildStaticDataset = (): TrainDataset => {
  const trains: TrainSummary[] = trainsEnvelope.Response;
  const stations: StationDetails[] = stationsEnvelope.Response;
  const stationMap = buildStationMap(stations);
  const routeByTrainId = buildRouteMap(trainStationsList);

  const dataset: TrainWithRoute[] = trains.map((train) => {
    const route = routeByTrainId.get(train.TrainId) ?? [];
    const upcomingStop = route[0];

    return {
      ...train,
      route,
      upcomingStop,
      previousStop: undefined
    };
  });

  return {
    trains: dataset,
    stationById: stationMap
  };
};

export const loadTrainDatasetSync = (): TrainDataset => buildStaticDataset();

export const STALE_LIVE_RUN_TTL_MS = 10 * 60 * 1000; // 10 minutes

const sameStop = (a?: TrainStop, b?: TrainStop): boolean => {
  if (!a && !b) return true;
  if (!a || !b) return false;
  return a.StationId === b.StationId && a.OrderNumber === b.OrderNumber;
};

const resetTrainLiveState = (train: TrainWithRoute): TrainWithRoute => {
  if (!train.livePosition && !train.liveRuns?.length && !train.selectedRunId && !train.IsLive) {
    return train;
  }

  const defaultUpcoming = train.route[0] ?? undefined;

  return {
    ...train,
    IsLive: false,
    livePosition: undefined,
    liveRuns: undefined,
    selectedRunId: undefined,
    upcomingStop: defaultUpcoming,
    previousStop: undefined
  };
};

const isRunFresh = (run: LiveTrainDelta, now: number): boolean => now - run.lastUpdated <= STALE_LIVE_RUN_TTL_MS;

const sanitizeTrainLiveState = (train: TrainWithRoute, now: number): TrainWithRoute => {
  const runs = train.liveRuns;

  if (!runs || runs.length === 0) {
    return resetTrainLiveState(train);
  }

  const freshRuns = runs.filter((run) => isRunFresh(run, now));

  if (freshRuns.length === 0) {
    return resetTrainLiveState(train);
  }

  const selectedRun = freshRuns.find((run) => run.id === train.selectedRunId) ?? freshRuns[0];

  const upcomingStop =
    selectedRun.nextStationId != null
      ? train.route.find((stop) => stop.StationId === selectedRun.nextStationId)
      : undefined;
  const previousStop =
    selectedRun.prevStationId != null
      ? train.route.find((stop) => stop.StationId === selectedRun.prevStationId)
      : undefined;

  const nextUpcoming = upcomingStop ?? train.upcomingStop;
  const nextPrevious = previousStop ?? train.previousStop;

  const requiresUpdate =
    freshRuns.length !== runs.length ||
    train.selectedRunId !== selectedRun.id ||
    train.livePosition !== selectedRun ||
    !sameStop(train.upcomingStop, nextUpcoming) ||
    !sameStop(train.previousStop, nextPrevious) ||
    !train.IsLive;

  if (!requiresUpdate) {
    return train;
  }

  return {
    ...train,
    IsLive: true,
    liveRuns: freshRuns,
    selectedRunId: selectedRun.id,
    livePosition: selectedRun,
    upcomingStop: nextUpcoming,
    previousStop: nextPrevious
  };
};

export const stripStaleLiveData = (trains: TrainWithRoute[], now: number = Date.now()): TrainWithRoute[] => {
  let mutated = false;
  const next = trains.map((train) => {
    const sanitized = sanitizeTrainLiveState(train, now);
    if (sanitized !== train) {
      mutated = true;
    }
    return sanitized;
  });

  return mutated ? next : trains;
};

const persistDataset = async ({ trains, stationById }: TrainDataset) => {
  const stations = Array.from(stationById.values());
  const normalizedTrains = stripStaleLiveData(trains);

  await db.transaction('rw', db.trains, db.stations, db.lastUpdated, async () => {
    await db.trains.clear();
    await db.stations.clear();

    await db.trains.bulkPut(normalizedTrains);
    await db.stations.bulkPut(stations);
    await db.lastUpdated.put({ name: 'dataset', timestamp: Date.now() });
  });
};

export const persistTrainSnapshot = async (
  trains: TrainWithRoute[],
  stationLookup?: Map<number, StationDetails>
) => {
  const normalizedTrains = stripStaleLiveData(trains);

  await db.transaction('rw', db.trains, db.lastUpdated, async () => {
    await db.trains.bulkPut(normalizedTrains);
    if (stationLookup) {
      await db.stations.bulkPut(Array.from(stationLookup.values()));
    }
    await db.lastUpdated.put({ name: 'dataset', timestamp: Date.now() });
  });
};

export const loadTrainDataset = async (): Promise<TrainDataset> => {
  const [storedTrains, storedStations] = await Promise.all([db.trains.toArray(), db.stations.toArray()]);

  if (storedTrains.length > 0 && storedStations.length > 0) {
    const normalizedTrains = stripStaleLiveData(storedTrains);
    if (normalizedTrains !== storedTrains) {
      await db.trains.bulkPut(normalizedTrains);
    }
    return {
      trains: normalizedTrains,
      stationById: buildStationMap(storedStations)
    };
  }

  const dataset = buildStaticDataset();
  await persistDataset(dataset);
  return dataset;
};

export const refreshTrainDataset = async (): Promise<TrainDataset> => {
  const dataset = buildStaticDataset();
  await persistDataset(dataset);
  return dataset;
};

export const findStopByStationId = (route: TrainStop[], stationId?: number | null): TrainStop | undefined => {
  if (!stationId) {
    return undefined;
  }
  return route.find((stop) => stop.StationId === stationId);
};
