import io from 'socket.io-client';
import type { SocketMessageEnvelope } from '@/types';
import { SOCKET_OPTIONS, SOCKET_URL, flattenSocketEnvelope } from './liveData';

type Socket = ReturnType<typeof io>;

type DeltaHandler = (deltas: ReturnType<typeof flattenSocketEnvelope>) => void;

export type SocketEvents = {
  onConnect?: () => void;
  onDisconnect?: (reason: string) => void;
  onReconnectAttempt?: (attempt: number) => void;
  onReconnect?: (attempt: number) => void;
  onError?: (error: Error) => void;
};

export const connectLiveSocket = (handler: DeltaHandler, events?: SocketEvents): (() => void) => {
  const socket: Socket = io(SOCKET_URL, {
    path: SOCKET_OPTIONS.path,
    transports: [...SOCKET_OPTIONS.transports],
    reconnection: SOCKET_OPTIONS.reconnection,
    reconnectionDelay: SOCKET_OPTIONS.reconnectionDelay,
    reconnectionAttempts: SOCKET_OPTIONS.reconnectionAttempts,
    timeout: SOCKET_OPTIONS.timeout,
    forceNew: SOCKET_OPTIONS.forceNew,
    autoConnect: SOCKET_OPTIONS.autoConnect,
    upgrade: SOCKET_OPTIONS.upgrade,
    query: SOCKET_OPTIONS.query,
    secure: SOCKET_OPTIONS.secure
  });

  const safeHandler = handler ?? (() => undefined);

  const handleEnvelope = (payload: SocketMessageEnvelope) => {
    const deltas = flattenSocketEnvelope(payload);
    if (deltas.length > 0) {
      safeHandler(deltas);
    }
  };

  socket.on('connect', () => {
    events?.onConnect?.();
  });

  socket.on('disconnect', (reason: string) => {
    events?.onDisconnect?.(reason);
  });

  socket.on('connect_error', (err: Error) => {
    events?.onError?.(err);
  });

  socket.on('error', (err: Error) => {
    events?.onError?.(err);
  });

  socket.io.on('reconnect_attempt', (attempt: number) => {
    events?.onReconnectAttempt?.(attempt);
  });

  socket.io.on('reconnect', (attempt: number) => {
    events?.onReconnect?.(attempt);
  });

  socket.on('all-newtrains-delta', handleEnvelope);
  socket.on('all-newtrains', handleEnvelope);
  socket.on('all-trains-delta', handleEnvelope);

  return () => {
    socket.off('all-newtrains-delta', handleEnvelope);
    socket.off('all-newtrains', handleEnvelope);
    socket.off('all-trains-delta', handleEnvelope);
    socket.off('connect');
    socket.off('disconnect');
    socket.off('connect_error');
    socket.off('error');
    socket.io.off('reconnect_attempt');
    socket.io.off('reconnect');
    socket.disconnect();
  };
};
