import Dexie, { Table } from 'dexie';
import { StationDetails, TrainWithRoute } from '@/types';

export class AppDB extends Dexie {
  trains!: Table<TrainWithRoute, number>;
  stations!: Table<StationDetails, number>;
  lastUpdated!: Table<{ name: string; timestamp: number }, string>;

  constructor() {
    super('PakRailDB');
    this.version(1).stores({
      trains: 'TrainId, TrainNumber, TrainName, IsUp, IsLive',
      stations: 'StationDetailsId, StationName',
      lastUpdated: 'name',
    });
  }
}

export const db = new AppDB();
