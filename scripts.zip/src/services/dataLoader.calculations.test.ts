import { describe, expect, it } from 'vitest';
import { STALE_LIVE_RUN_TTL_MS, stripStaleLiveData } from './dataLoader';
import type { LiveTrainDelta, TrainStop, TrainWithRoute } from '@/types';

const buildStop = (stationId: number, order: number): TrainStop => ({
  TrainNumber: 1,
  TrainName: 'Test Express',
  StationId: stationId,
  ArrivalTime: '10:00',
  IsDayChanged: 0,
  DayCount: 0,
  DepartureTime: '10:05',
  IsUp: 1,
  OrderNumber: order,
  StationName: `Station ${stationId}`,
  Latitude: 30 + order,
  Longitude: 70 + order
});

const buildLiveRun = (overrides: Partial<LiveTrainDelta>): LiveTrainDelta => ({
  id: 'run-1',
  trainKey: 'train-key',
  variantKey: 'variant-key',
  locomitiveNo: null,
  lat: 0,
  lon: 0,
  lastUpdated: Date.now(),
  lateBy: 0,
  nextStationId: 2,
  nextStopName: 'Station 2',
  prevStationId: 1,
  speed: 45,
  trainNumber: 1,
  dayNumber: 0,
  isTrainStation: false,
  isTrainStop: false,
  isFlagged: false,
  iconUrl: null,
  statusCode: 'A',
  direction: 'up',
  ...overrides
});

const buildTrain = (overrides: Partial<TrainWithRoute>, run: LiveTrainDelta): TrainWithRoute => {
  const route = [buildStop(1, 1), buildStop(2, 2), buildStop(3, 3)];

  return {
    TrainId: 1,
    TrainNumber: 1,
    TrainName: 'Test Express',
    TrainNameUR: 'ٹیسٹ',
    TrainNameWithNumber: 'Test Express 1',
    TrainDescription: 'Sample route',
    IsActive: true,
    Imei: null,
    IsLive: true,
    IsUp: true,
    LocomotiveNumber: null,
    TrainRideId: 1,
    AllocatedDate: null,
    route,
    upcomingStop: route[1],
    previousStop: route[0],
    liveRuns: [run],
    livePosition: run,
    selectedRunId: run.id,
    ...overrides
  };
};

describe('stripStaleLiveData', () => {
  it('leaves fresh live runs intact', () => {
    const now = 10_000;
    const freshRun = buildLiveRun({ lastUpdated: now - STALE_LIVE_RUN_TTL_MS + 1000 });
    const train = buildTrain({}, freshRun);
    const dataset = [train];

    const result = stripStaleLiveData(dataset, now);

    expect(result).toBe(dataset);
    expect(result[0].livePosition).toBe(freshRun);
    expect(result[0].IsLive).toBe(true);
  });

  it('resets trains whose runs are stale', () => {
    const now = 50_000;
    const staleRun = buildLiveRun({ lastUpdated: now - STALE_LIVE_RUN_TTL_MS - 1 });
    const train = buildTrain({}, staleRun);

    const [sanitized] = stripStaleLiveData([train], now);

    expect(sanitized).not.toBe(train);
    expect(sanitized.IsLive).toBe(false);
    expect(sanitized.livePosition).toBeUndefined();
    expect(sanitized.liveRuns).toBeUndefined();
    expect(sanitized.selectedRunId).toBeUndefined();
    expect(sanitized.upcomingStop?.StationId).toBe(train.route[0].StationId);
    expect(sanitized.previousStop).toBeUndefined();
  });

  it('keeps partial fresh runs and prunes stale ones', () => {
    const now = 100_000;
    const freshRun = buildLiveRun({ id: 'fresh', lastUpdated: now - 1000, nextStationId: 3 });
    const staleRun = buildLiveRun({ id: 'stale', lastUpdated: now - STALE_LIVE_RUN_TTL_MS - 1 });
    const train = buildTrain({ liveRuns: [freshRun, staleRun], livePosition: staleRun, selectedRunId: staleRun.id }, freshRun);

    const [sanitized] = stripStaleLiveData([train], now);

    expect(sanitized.liveRuns).toHaveLength(1);
    expect(sanitized.liveRuns?.[0].id).toBe('fresh');
    expect(sanitized.selectedRunId).toBe('fresh');
    expect(sanitized.livePosition?.id).toBe('fresh');
    expect(sanitized.upcomingStop?.StationId).toBe(3);
  });
});
