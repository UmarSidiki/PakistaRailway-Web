import { describe, expect, it } from 'vitest';
import { isPassengerTrain } from './classification';
import type { TrainWithRoute } from '@/types';

const buildTrain = (overrides: Partial<TrainWithRoute> = {}): TrainWithRoute => ({
  TrainId: 1,
  TrainNumber: overrides.TrainNumber ?? 45,
  TrainName: overrides.TrainName ?? 'Sample 45UP',
  TrainNameUR: overrides.TrainNameUR ?? 'نمونہ',
  TrainNameWithNumber: overrides.TrainNameWithNumber ?? 'Sample 45UP',
  TrainDescription: overrides.TrainDescription ?? null,
  IsActive: overrides.IsActive ?? true,
  Imei: overrides.Imei ?? null,
  IsLive: overrides.IsLive ?? false,
  IsUp: overrides.IsUp ?? true,
  LocomotiveNumber: overrides.LocomotiveNumber ?? null,
  TrainRideId: overrides.TrainRideId ?? 0,
  AllocatedDate: overrides.AllocatedDate ?? null,
  route: overrides.route ?? [],
  upcomingStop: overrides.upcomingStop,
  previousStop: overrides.previousStop,
  livePosition: overrides.livePosition,
  liveRuns: overrides.liveRuns,
  selectedRunId: overrides.selectedRunId
});

describe('isPassengerTrain', () => {
  it('identifies trains with explicit direction tags as passenger', () => {
    expect(isPassengerTrain(buildTrain({ TrainName: '15UP' }))).toBe(true);
    expect(isPassengerTrain(buildTrain({ TrainName: '15DN' }))).toBe(true);
    expect(isPassengerTrain(buildTrain({ TrainName: 'Tezgam - 15UP' }))).toBe(true);
    expect(isPassengerTrain(buildTrain({ TrainName: '15 - DN Special' }))).toBe(true);
    expect(isPassengerTrain(buildTrain({ TrainName: 'UP-15 Shuttle' }))).toBe(true);
  });

  it('uses passenger service keywords when direction tags are absent', () => {
    expect(isPassengerTrain(buildTrain({ TrainName: 'Shalimar Express' }))).toBe(true);
    expect(isPassengerTrain(buildTrain({ TrainName: 'Khyber Mail' }))).toBe(true);
  });

  it('excludes trains flagged by cargo heuristics', () => {
    expect(isPassengerTrain(buildTrain({ TrainName: 'Coal Express' }))).toBe(false);
    expect(isPassengerTrain(buildTrain({ TrainName: 'Goods Special DN' }))).toBe(false);
  });

  it('excludes trains above the cargo threshold', () => {
    expect(
      isPassengerTrain(
        buildTrain({
          TrainName: '5001UP',
          TrainNumber: 5001
        })
      )
    ).toBe(false);
  });

  it('does not mistake unrelated words containing up/dn for passenger tags', () => {
    expect(isPassengerTrain(buildTrain({ TrainName: 'Setup Crew Train' }))).toBe(false);
  });
});
