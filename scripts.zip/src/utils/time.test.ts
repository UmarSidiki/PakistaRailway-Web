import { describe, expect, it } from 'vitest';
import {
  formatDuration,
  formatLateBy,
  formatRelativeTime,
  formatTime,
  calculateExpectedArrival,
  calculateDistance
} from './time';

describe('time utilities', () => {
  it('formats duration in hours and minutes', () => {
    expect(formatDuration(125)).toBe('2 hrs 5 min');
    expect(formatDuration(60)).toBe('1 hr');
    expect(formatDuration(0)).toBe('Under 1 min');
    expect(formatDuration(null)).toBe('—');
  });

  it('formats lateness information correctly', () => {
    expect(formatLateBy(null)).toBe('On time');
    expect(formatLateBy(0)).toBe('On time');
    expect(formatLateBy(12)).toBe('12 min late');
    expect(formatLateBy(-7)).toBe('7 min early');
  });

  it('formats clock times into 12-hour representation', () => {
    expect(formatTime('14:05')).toBe('2:05 PM');
    expect(formatTime('00:00')).toBe('12:00 AM');
    expect(formatTime('23:59:30')).toBe('11:59 PM');
    expect(formatTime(undefined)).toBe('—');
  });

  it('describes relative time for timestamps', () => {
    const now = Date.now();
    expect(formatRelativeTime(now)).toBe('Just now');
    expect(formatRelativeTime(now - 5 * 60 * 1000)).toBe('5 minutes ago');
    expect(formatRelativeTime(now + 2 * 60 * 1000)).toBe('in 2 minutes');
    expect(formatRelativeTime(null)).toBe('No updates');
  });

  it('calculates expected arrival when distance and speed are present', () => {
    const result = calculateExpectedArrival(30, 60);
    expect(result).not.toBeNull();
    expect(result?.minutes).toBe(30);
    expect(result?.durationLabel).toBe('30 min');
    expect(result?.timeString).toMatch(/AM|PM/);
  });

  it('returns null for expected arrival when speed is insufficient', () => {
    expect(calculateExpectedArrival(50, null)).toBeNull();
    expect(calculateExpectedArrival(50, 0)).toBeNull();
    expect(calculateExpectedArrival(50, 3)).toBeNull();
  });

  it('computes distance using the haversine formula', () => {
    const distance = calculateDistance(0, 0, 0, 1);
    expect(distance).toBeGreaterThan(111);
    expect(distance).toBeLessThan(112);
  });
});
