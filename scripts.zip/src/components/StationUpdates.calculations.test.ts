import { describe, expect, it } from 'vitest';
import { __stationUpdatesInternals } from './StationUpdates';

const { getExpectedArrivalDetails } = __stationUpdatesInternals;

describe('StationUpdates expected arrival calculations', () => {
  it('returns null when no scheduled time is available', () => {
    expect(getExpectedArrivalDetails(null, 10)).toBeNull();
  });

  it('returns the scheduled time when no live adjustment exists', () => {
    const result = getExpectedArrivalDetails('14:30', null);
    expect(result).not.toBeNull();
    expect(result?.display).toBe('2:30 PM');
    expect(result?.scheduledLabel).toBe('2:30 PM');
    expect(result?.hasLiveAdjustment).toBe(false);
    expect(result?.disruptionLabel).toBe('On time');
  });

  it('applies late minutes to produce an adjusted arrival time', () => {
    const result = getExpectedArrivalDetails('14:30', 15);
    expect(result).not.toBeNull();
    expect(result?.display).toBe('2:45 PM');
    expect(result?.scheduledLabel).toBe('2:30 PM');
    expect(result?.hasLiveAdjustment).toBe(true);
    expect(result?.disruptionLabel).toBe('15 min late');
  });

  it('handles trains arriving early by subtracting minutes', () => {
    const result = getExpectedArrivalDetails('14:30', -10);
    expect(result).not.toBeNull();
    expect(result?.display).toBe('2:20 PM');
    expect(result?.hasLiveAdjustment).toBe(true);
    expect(result?.disruptionLabel).toBe('10 min early');
  });

  it('wraps around midnight when adjustments cross the day boundary', () => {
    const result = getExpectedArrivalDetails('23:50', 20);
    expect(result).not.toBeNull();
    expect(result?.display).toBe('12:10 AM');
    expect(result?.scheduledLabel).toBe('11:50 PM');
  });
});
